#!/bin/bash
set -e
[ -z "$1" ] && { echo "Usage: ./apply.sh /path/to/theme"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; cd "$1"
rsync -a --exclude README.md --exclude apply.sh "$SRC"/ ./
shopify theme check
git add -A
git diff --cached --quiet || git commit -m "S1 foundation lock: footer menu binding, credits, image guides, design controls"
echo "Done. Push manually when ready."

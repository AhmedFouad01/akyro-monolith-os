# S1 — Foundation Lock
Branch: claude/s1-foundation-lock · Commit: f59f464 · Theme Check: PASS (56 files, 0 offenses)

## Delivered
1. M03-C1 footer menu binding — section settings show_footer_menu (default true) + footer_menu link_list (default handle "footer"); renders as first column; nothing renders if menu missing/empty; blocks/access/switcher/tagline/copyright untouched. Labels via schema locales EN+AR; header/footer group names fixed.
2. Credits — settings_schema theme_info: AKYRO MONOLITH OS v0.9.0, author Ahmed Fouad (docs/support URLs placeholder — send real ones).
3. Image guides — schema info on hero/page-hero/collection pickers (sizes from IMAGE_ASSET_PLAN_25) + snippets/image-guide.liquid: design-mode-only red warning when uploaded image deviates >10% from expected ratio or is under min width. Zero output on live store.
4. Design controls (Theme settings → Design controls): container width 1200–1680, corner radius 0–8 (info notes AKYRO system = 0), animation speed 120–320ms, section spacing scale — wired via token overrides in theme.liquid; all components inherit automatically.
5. Type scale completed: --text-display / --text-caption / --font-mono tokens + .display/.caption/.mono utilities.

## Apply
./apply.sh /path/to/theme
Then in TE: footer section → confirm "Footer menu" picker shows Admin menu (handle footer).
